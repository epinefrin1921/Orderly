create view PREGLED2 as
(
                      select m."MI_ID",m."MI_PRICE",m."MI_NAME",m."MI_DESCRIPTION",m."MI_SUPPLY_PRICE",m."MI_IMG",m."MI_TYPE", IN_ID, r."RL_ID",r."RL_INGREDIENT",r."RL_MENU",r."RL_QUANTITY"
                      from INGREDIENTS i, RECIPE_LINE r, MENU_ITEMS m
                      where IN_ID=r.RL_INGREDIENT and m.MI_ID=r.RL_MENU and i.IN_ID=3
                      )
/

